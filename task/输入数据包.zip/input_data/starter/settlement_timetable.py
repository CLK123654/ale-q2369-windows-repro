from datetime import timedelta

# 当前starter按固定24小时生成区间，也没有Airflow Timetable序列化。
class BrokenSettlementTimetable:
    def infer_manual_data_interval(self, run_after):
        end = run_after.replace(hour=0, minute=0, second=0, microsecond=0)
        return end - timedelta(hours=24), end

    def next_interval(self, start):
        end = start + timedelta(hours=24)
        return start, end, end + timedelta(hours=6, minutes=30)
