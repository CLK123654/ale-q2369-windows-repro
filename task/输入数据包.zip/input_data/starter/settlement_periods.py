# 当前starter去掉时区后只用本地钟点作键，回拨日02:00会冲突。
def period_key(local_datetime):
    naive = local_datetime.replace(tzinfo=None)
    return naive.strftime("%Y-%m-%dT%H:%M")
